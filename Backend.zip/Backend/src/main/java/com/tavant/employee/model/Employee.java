package com.tavant.employee.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="Employee")
public class Employee {
	
	@Id
	private Integer employeeId;
	@NotBlank(message="First Name Should not be Blank")
	private String firstName;
	@NotBlank(message="Last Name Should not be Blank")
	private String lastName;
	@NotBlank(message="Address Name Should not be Blank")
	private String address;
	@NotBlank(message="Email Name Should not be Blank")
	private String email;

}
