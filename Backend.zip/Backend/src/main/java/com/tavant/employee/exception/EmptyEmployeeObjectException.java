package com.tavant.employee.exception;

public class EmptyEmployeeObjectException extends Exception {
	
	public EmptyEmployeeObjectException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

	@Override
	public String toString() {
		
		return super.toString()+this.getMessage();	
	}
	
}
