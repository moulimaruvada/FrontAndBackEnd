package com.tavant.employee.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tavant.employee.exception.EmployeeNotFoundException;
import com.tavant.employee.exception.EmptyEmployeeObjectException;
import com.tavant.employee.exception.NoEmployeeFoundException;
import com.tavant.employee.model.Employee;
import com.tavant.employee.repository.EmployeeRepository;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/")
public class EmployeeController {
	
	@Autowired
	EmployeeRepository employeeRepository;
	@GetMapping
	public String getEmployee() {
		return "Inside Employee Account";
	}
	
	@GetMapping("/employee")
	public ResponseEntity<?> getAllEmployees() throws NoEmployeeFoundException {
		// To get all the employees
		Optional<List<Employee>> optional = Optional.of(employeeRepository.findAll());
		if(optional.isEmpty()) {
			throw new NoEmployeeFoundException("Employee Details Not found");
		}
		else {
			return ResponseEntity.ok(optional.get());
		}

	}
	@GetMapping("/employee/{employeeId}")
	public ResponseEntity<?> getEmployeeByID(@PathVariable ("employeeId") Integer id) throws EmployeeNotFoundException {
		Optional<Employee> optional = employeeRepository.findById(id);
		
		//to get employee by id
		if(optional.isPresent()) {
			return ResponseEntity.ok(optional.get());
		}
		else {
			throw new EmployeeNotFoundException("No Employee Found");
		}
		
	}
	@PostMapping("/employee")
	public Employee addEmployee(@RequestBody@Valid Employee employee) throws EmptyEmployeeObjectException {
		// To add an employee Details
		if(employee.getEmployeeId()==null) {
			throw new EmptyEmployeeObjectException("Provide a Correct object"); 
		}
		return employeeRepository.save(employee);
		
	}
	
	@DeleteMapping("/employee/{employeeId}")
	public String deleteEmployee(@PathVariable("employeeId") Integer id) throws EmployeeNotFoundException {
		// To delete an employee
		Employee employee = employeeRepository.findById(id).orElseThrow(()-> new EmployeeNotFoundException("Employee is Not Found")); 
		employeeRepository.delete(employee);
		return "Employee Deleted";
		
	}
	@PutMapping("/employee/{employeeId}")
	public ResponseEntity<?> updateEmployee(@PathVariable(value="employeeId") Integer id, @Valid @RequestBody Employee EmployeeDetails) throws EmployeeNotFoundException {
		// To update the employee
		Employee employee = employeeRepository.findById(id).orElseThrow(()-> new EmployeeNotFoundException("There is no employee with the specific ID"));
		employee.setEmployeeId(EmployeeDetails.getEmployeeId());
		employee.setFirstName(EmployeeDetails.getFirstName());
		employee.setLastName(EmployeeDetails.getLastName());
		employee.setAddress(EmployeeDetails.getAddress());
		employee.setEmail(EmployeeDetails.getEmail());
		
		final Employee UpdatedEmployee = employeeRepository.save(employee);
		return ResponseEntity.ok(UpdatedEmployee);
		
		
	}
	
	
	
	
	
	

}
