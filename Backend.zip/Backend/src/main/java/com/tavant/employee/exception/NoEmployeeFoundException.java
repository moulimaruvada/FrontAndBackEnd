package com.tavant.employee.exception;

public class NoEmployeeFoundException extends Exception {
	
	public NoEmployeeFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

	@Override
	public String toString() {
		
		return super.toString()+this.getMessage();	
	}

}