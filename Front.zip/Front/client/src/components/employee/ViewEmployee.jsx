import React, { useState, useEffect } from "react";
import PropTypes from "prop-types";

import {
  Button,
  Card,
  CardBody,
  CardFooter,
  Col,
  Container,
  Form,
  Input,
  InputGroup,
  InputGroupAddon,
  InputGroupText,
  Row,
} from "reactstrap";
import axios from "axios";
const ViewEmployee = (props) => {
  const [employee, setEmployee] = useState({
    employeeId: "",
    firstName: "",
    lastName: "",
    address: "",
    email: "",
  });

  const Url = "http://localhost:9000/api/employee/" + props.match.params.id;

  useEffect(() => {
    const GetData = async () => {
      const result = await axios.get(Url);
      setEmployee(result.data);
    };
    GetData();
  }, []);

  return (
    <div className="app flex-row align-items-center">
      <Container>
        <Row className="justify-content-center">
          <Col md="12" lg="10" xl="8">
            <Card className="mx-4">
              <CardBody className="p-4">
                <Form onSubmit="">
                  <h1>View Employee</h1>
                  <InputGroup className="mb-3">
                    <Input
                      type="text"
                      placeholder="employeeId"
                      name="employeeId"
                      id="employeeId"
                      value={employee.employeeId}
                    />
                  </InputGroup>
                  <InputGroup className="mb-3">
                    <Input
                      type="text"
                      placeholder="firstName"
                      name="firstName"
                      id="firstName"
                      value={employee.firstName}
                    />
                  </InputGroup>
                  <InputGroup className="mb-4">
                    <Input
                      type="text"
                      placeholder="lastName"
                      name="lastName"
                      id="lastName"
                      value={employee.lastName}
                    />
                  </InputGroup>
                  <InputGroup className="mb-4">
                    <Input
                      type="text"
                      placeholder="address"
                      name="address"
                      id="address"
                      value={employee.address}
                    />
                  </InputGroup>

                  <InputGroup className="mb-4">
                    <Input
                      type="text"
                      placeholder="email"
                      name="email"
                      id="email"
                      value={employee.email}
                    />
                  </InputGroup>
                  <CardFooter className="p-4">
                    <Row>
                      <Col xs="12" sm="12">
                        <Button
                          className="btn btn-info mb-1"
                          onClick={() => {
                            props.history.push("/EmployeeList");
                          }}
                          block
                        >
                          <span>Back</span>
                        </Button>
                      </Col>
                    </Row>
                  </CardFooter>
                </Form>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

ViewEmployee.propTypes = {};

export default ViewEmployee;
