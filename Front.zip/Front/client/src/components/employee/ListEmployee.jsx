import React, { useEffect, useState } from "react";
import PropTypes from "prop-types";

import {
  Badge,
  Card,
  CardBody,
  CardHeader,
  Col,
  Pagination,
  PaginationItem,
  PaginationLink,
  Row,
  Table,
} from "reactstrap";
import axios from "axios";
const ListEmployee = (props) => {
  const [data, setData] = useState([]);
  useEffect(() => {
    const GetData = async () => {
      const result = await axios("http://localhost:9000/api/employee/");
      console.log(result.data);
      setData(result.data);
    };
    GetData();
  }, []);

  const deleteemployee = async (id) => {
    await axios
      .delete("http://localhost:9000/api/employee/" + id)
      .then((result) => props.history.push("/EmployeeList"));
  };

  const editemployee = (id) => {
    props.history.push({
      pathname: "/edit/" + id,
    });
  };

  const viewemployee = (id) => {
    props.history.push({
      pathname: "/view/" + id,
    });
  };

  return (
    <div className="animated fadeIn">
      <Row>
        <Col>
          <Card>
            <CardHeader>
              <i className="fa fa-align-justify"></i> Employee List
            </CardHeader>
            <CardBody>
              <Table hover bordered striped responsive size="sm">
                <thead>
                  <tr>
                    <th>Employee ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Address</th>
                    <th>Email</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((item, idx) => {
                    return (
                      <tr>
                        <td>{item.employeeId}</td>
                        <td>{item.firstName}</td>
                        <td>{item.lastName}</td>
                        <td>{item.address}</td>
                        <td>{item.email}</td>
                        <td>
                          <div class="btn-group">
                            <button
                              className="btn btn-warning"
                              onClick={() => {
                                editemployee(item.employeeId);
                              }}
                            >
                              Edit
                            </button>
                            <button
                              className="btn btn-warning"
                              onClick={() => {
                                deleteemployee(item.employeeId);
                              }}
                            >
                              Delete
                            </button>
                            <button
                              className="btn btn-warning"
                              onClick={() => {
                                viewemployee(item.employeeId);
                              }}
                            >
                              View
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </Table>
            </CardBody>
          </Card>
        </Col>
      </Row>
    </div>
  );
};

ListEmployee.propTypes = {};

export default ListEmployee;
